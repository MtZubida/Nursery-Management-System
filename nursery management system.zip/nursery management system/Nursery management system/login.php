
<!DOCTYPE html>
<html >
    <head>

        <link rel="stylesheet" href="style.css">

        
  
    </head>
    <body class="bd1">
        
        <form  id="f1" method="post"   action="" class="box"   >
            <h2>LOG  IN</h2>
            Username <input type="text" id="emailid" value="" placeholder="Enter username" >
            Password <input type="password" id="pass" vlue=""  placeholder="Enter Password" >  
            <button class="button" type="submit" name="submit" value="log in"  ></button><br>
            <a href="index.php" class="b1">back</a>
        </form>
    </body>
    
</html>