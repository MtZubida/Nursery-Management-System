<?php

if(isset($_POST["submit"])){

      if($_POST["pass"]==$_POST["cpass"]){
         $uname = $_POST["uname"];
         $phnname=$_POST["phnname"];
         $adress=$_POST["adress"];
          $emailid = filter_var($_POST["emailid"],FILTER_SANITIZE_EMAIL);

             $pass=$_POST["pass"];
             $type=$_POST["tname"];

             if(filter_var($emailid,FILTER_VALIDATE_EMAIL)){

              $conn=mysqli_connect("localhost","root","","app_user");
              
              $sql="SELECT  *FROM userdata WHERE emailid = '$emailid'  ";

              $result=mysqli_query($conn,$sql);
              $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
              $count=mysqli_num_rows($result);
              //echo $count;
                 if($count==0){
              $sql="INSERT INTO userdata(username,phonenumber,emailid,uaddress, upassword,types) 
              VALUES('$uname','$phnname','$emailid','$adress','$pass','$type')";

              if(mysqli_query($conn,$sql)){

                  session_start();

                  $_SESSION["emailid"]=$_POST["emailid"];

                  echo"Registration Accepted<br>";

                  header ("refresh:2; url=private.php");
              }
            }
            else{
                echo "multiple user present";
                header("refresh:2; url=signup.php");
            }
            }
              else{
                echo"Email format is not correct";
                header("refresh:2; url=index.php");
               
  
  
            }
            }
            else{
                echo"please make sure both password fields are same";
                header("refresh:2; url=index.php");
               
            }             
      
}

?>