<!DOCTYPE html>
<html lang="en">
<head>

</head>
<body>
    <h1>Update Employee</h1>
    <form action="eupdate.php" method="post" enctype="multipart/form-data">
        Employee id  <input type="text" name="eid" ><br><br>
        Employee name   <input type="text" name="ename" ><br><br>
        Employee age <input type ="text" name="eage" ><br><br>
        Employee phn  <input type="number" name="ephn" ><br><br>
        emailid <input type="text" name="emailid" ><br><br>
        status<input type="radio" name="sname" value="active">
        active
        <input type="radio" name="sname" value="Inactive">
        inactive
        <br><br>
        <input type ="submit" name="update"><br>
        <a href="employee.php">Back</a>

</form>
</body>
</html>
<?php
  
  $conn=mysqli_connect("localhost","root","","app_user");
 if(isset($_POST["update"])){
      $id=$_POST["eid"];
      $query="UPDATE edata SET ename='$_POST[ename]',eage='$_POST[eage]',
      emailid='$_POST[emailid]',ephn='$_POST[ephn]',status='$_POST[sname]'
     where  eid='$id'";
      $result=mysqli_query($conn,$query);
      if($result){
          echo "update Employee ";
          header ("refresh:2; url=employee.php");
      }
      else{
        echo "update not  Employee ";
        header ("refresh:2; url=employee.php");
      }
  }



?>