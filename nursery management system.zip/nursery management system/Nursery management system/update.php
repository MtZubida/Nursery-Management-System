<?php
$conn=mysqli_connect("localhost","root","","app_user");
$rn=$_GET['rn'];
$pn=$_GET['pn'];
$pd=$_GET['pd'];
$pr=$_GET['pr'];
$pc=$_GET['pc'];
$st=$_GET['st'];
echo $pr;
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <title>update Plant </title>
    <link rel="stylesheet" href="log.css">
</head>
<body class="bd1">
    
    <form action="update.php" method="post" enctype="multipart/form-data" class="box">
               <h1>Update plant details</h1>
        plantid  <input type="text" name="plantid" value="<?php echo "$rn"?>"><br><br>
        plantname   <input type="text" name="pname" value="<?php echo "$pn"?>"><br><br>
        plantdescription  <input type ="text" name="dname" value="<?php echo $pd?>"><br><br>
        price   <input type="number" name="price" value="<?php echo "$pr"?>"><br><br>
        product catagory <input type="text" name="pca" value="<?php echo $pc?>"><br><br>
        status<input type="radio" name="sname" value="available">
        Available
        <input type ="radio" name="sname" value="not available" >
        Not Available
        <br><br>
        <input type ="submit" name="update">
        <a href="plantinsert.php" class="b1">Back</a>
</form>
</body>
</html>
<?php
  
  $conn=mysqli_connect("localhost","root","","app_user");
 if(isset($_POST["update"])){
      $id=$_POST["plantid"];
      $query="UPDATE plantsdata SET plantname='$_POST[pname]',plantdescribtion='$_POST[dname]',
      price='$_POST[price]',plantcatagory='$_POST[pca]',status='$_POST[sname]'
     where  plantid='$id'";
      $result=mysqli_query($conn,$query);
      if($result){
          echo "update palnt ";
          header ("refresh:2; url=plantinsert.php");
      }
      else{
        echo "update not  palnt ";
        header ("refresh:2; url=plantinsert.php");
      }
  }



?>