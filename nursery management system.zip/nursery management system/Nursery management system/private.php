<?php
$token="";
$token2="";
session_start();
if(isset($_SESSION["emailid"])){
    echo"Hello .you are now logged in"."<br>";
    echo "";
    $token="signout.php";
    $token2="Sign out";
 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  
    <title>PHp app</title>
</head>
<body>
    <p style="text-align:left">
    <?php
       if(isset($_SESSION["emailid"])){
           echo "Username:"."<b style=\"color:red\">".$_SESSION["emailid"]."</b><br>";
           echo"<br>your profile pic:<br>";
           echo"<img src='1.png'>";

       }
    ?>
    </p>
    <br>
 <a href="index.php">Back</a>
 <a href=<?php echo $token;?>><?php echo $token2;?></a>
</body>
</html>