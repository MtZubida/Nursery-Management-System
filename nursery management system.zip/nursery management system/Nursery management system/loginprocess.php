
<?php
if(isset($_POST["submit"])){
    $emailid1=$_POST["ename"];
    $pass=$_POST["passw"];
     //$tname=$_POST["tname1"];
    $conn=mysqli_connect("localhost","root","","app_user");
   echo $emailid1;
    // $sql="SELECT  *FROM userdata WHERE emailid = '$emailid1' and upassword = '$pass' ";
    $sql1="SELECT types  FROM userdata WHERE emailid='$emailid1' and upassword='$pass'";
    $result=mysqli_query($conn,$sql1);
    
    $count=mysqli_num_rows($result);
    session_start();
    while($data5=mysqli_fetch_assoc($result)){
     $d=$data5['types'];
     
        if ( $count==1 && $d=="admin" ){
           
            $_SESSION["emailid"]=$emailid1;
            echo "you are now redirected";
            header ("refresh:2; url=plantdetail.php");
            exit();
        }
        else if ( $count==1 && $d=='user' ){
            header ("refresh:2; url=customerview.php");
            exit(); 
        }
       
    }
    
        echo"user not found";
     header ("refresh:4; url=log.html");
     exit();   
    
}

?>