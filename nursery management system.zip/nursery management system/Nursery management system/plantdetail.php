<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>admin page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
        <ul>
         <li style="float:left"><h3 id="i1">nursery store</h3></li>
         <li><a href="index.php"> sign out</a></li>
         <li><a href="index.php">About Us</a></li>
         <li><a href="index.php">Contact Us</a></li>
         <li><a href="signup.html"  >Registration</a></li> 
         <li><a href="log.html" >Log In</a></li>
</ul>
<div class ="box4">
<a href="plantinsert.php"><h2> plant List</h2></a>
<a href="orderadmin.php"><h2> order List</h2></a>  
</div>
</body>
</html>