<?php
      if(session_status()>=0){
           session_start();
           if(isset($_SESSION["emailid"])){
             //header("refresh:0.5; url=private.php");
            }
        }
        $conn=mysqli_connect("localhost","root","","app_user");
         $sql="SELECT plantname,price,plantcatagory,plantid,image FROM plantsdata";
        $result=mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
   
    
      <link rel="stylesheet" href="style.css">
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body>

        <ul>
         <li style="float:left"><h3 id="i1">nursery store</h3></li>
         <li><a href="index.php">About Us</a></li>
         <li><a href="index.php">Contact Us</a></li>
         <li><a href="signup.html"  >Registration</a></li> 
         <li><a href="log.html" >Log In</a></li>
         
         <!--
             <li><a href="index.php">Plant Catagory</a></li>
         <form action="index.php" method ="post" class="in1">
         <input type="text" name="t1" placeholder="Srech plants" >
         <input type="submit"name="Go" value="Go" id="in2">-->

        </ul>
            <!--<img src="3.png" width="1500" height="500">-->
                <div class="ps">
                   <p class="hm1">Get 10% Discount <br>
                   On Order Above taka 1599/-</p> 
                </div>
                        


                    <?php 
                        if ($result) {
                              $i=0; 
                               while($data=mysqli_fetch_array($result)) { 
                                     $arr[$i]=$data['plantname'];
                                     $arr1[$i]=$data['price'];
                                     $arr2[$i]=$data['image'];
                                     $i++;
                     
                                 } 
                        }
                    ?>

        <div class="container ">
            <h1 style="text-align:center">PLANTS</h1>
            <?php for ($a=0;$a<$i;$a++){?> 
           
            <div class="row">
                <div class="col-sm-4 ">
                    <div> <form method="post" action="cartview.php?id=<?php //echo $data["plantid"];?>">
                    <img src="<?=$arr2[$a];?>" width="300"height="250">
                        <div > <?= $arr[$a];?></div>
                        <div >$<?=number_format($arr1[$a],2);?></div>
                        <input type="number" name="quantity" value="1">
                        <input type="hidden" name="hiddename" value="<?=$arr[$a]?>">
                        <input type="hidden" name="hiddenprice" value="<?=$arr1[$a]?>">
                        <div class="dn">
                        <input type="submit" name="add" class="cart" value="Add to Cart"></a>
                        </div>
            
                        <?php $a++;?>
                        </form></div>  
                </div>

                <?php if($a!=$i){?>
                    <div class="col-sm-4">
                        <div> <form method="post" action="cartview.php?id=<?php //echo $data["plantid"];?>">
                        <img src="<?=$arr2[$a];?>" width="300"height="250">
                        <div> <?= $arr[$a];?></div>
                        <div>$<?=number_format($arr1[$a],2);?></div>
                        <input type="number" name="quantity" value="1">
                        <input type="hidden" name="hiddename" value="<?=$arr[$a]?>">
                        <input type="hidden" name="hiddenprice" value="<?=$arr1[$a]?>">
                        <div class="dn">
                        <input type="submit" name="add" class="cart" value="Add to Cart"></a>
                        </div>
                        <?php $a++;?>
                        </form></div>
                    </div>
                <?php }?>

                    <?php if($a<$i){?>
                        <div class="col-sm-4">
                            <div> <form method="post" action="cartview.php?id=<?php //echo $data["plantid"];?>">
                            <img src="<?=$arr2[$a];?>" width="300"height="250">
                            <div> <?= $arr[$a];?></div>
                            <div>$<?=number_format($arr1[$a],2);?></div>
                            <input type="number" name="quantity" value="1">
                            <input type="hidden" name="hiddename" value="<?=$arr[$a]?>">
                            <input type="hidden" name="hiddenprice" value="<?=$arr1[$a]?>">
                            <div class="dn">
                                <input type="submit" name="add" class="cart" value="Add to Cart"></a>
                            </div>
                            </form></div>
                        </div>
                    <?php }?>
            </div> 
            
         <?php }?>   
        
        </div>


    </body>
</html>