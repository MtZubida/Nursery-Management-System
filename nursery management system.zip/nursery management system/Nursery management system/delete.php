<?php
$conn=mysqli_connect("localhost","root","","app_user");

$plid=$_GET['rn'];
echo $plid;
$query="DELETE FROM plantsdata where plantid='$plid'";
$data=mysqli_query($conn,$query);
if($data){
    echo "REcord deleted from database";
    header ("refresh:3; url=plantinsert.php");
}else{
    echo"record not delete from database";
    header ("refresh:2; url=plantinsert.php");
}






?>