<?php
$conn=mysqli_connect("localhost","root","","app_user");
$plid=$_GET['rn'];


$query="DELETE FROM cart where serid='$plid'";
$data=mysqli_query($conn,$query);
if($data){
    echo "delete item";
    header ("refresh:3; url=cartview.php");
}else{
    echo"item not delete ";
    header ("refresh:2; url=cartview.php");
}
?>