<?php
$conn=mysqli_connect("localhost","root","","app_user");
if(isset($_POST["add"])){
    
    $itemid=$_GET["id"];
    $iname=$_POST["hiddename"];
    $iprice=$_POST["hiddenprice"];
    $quality=$_POST["quantity"];
    echo $iname;
    
$sql="INSERT INTO cart(iname,price,quality) VALUES('$iname','$iprice','$quality')";
$result=mysqli_query($conn,$sql); 
}

?>


<!DOCTYPE html>
<html lang="en">
    <head>
      <link rel="stylesheet" href="style.css">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    </head>
    <body>
    <ul>
         <li style="float:left"><h3 id="i1">nursery store</h3></li>
         <li><a href="index.php">About Us</a></li>
         <li><a href="index.php">Contact Us</a></li>
         <li><a href="signup.html"  >Registration</a></li> 
         <li><a href="log.html" >Log In</a></li></ul>
            <div class="container">
                <h1 style="text-align:center">My Cart</h1>
                <table class="tabl1">
                    <thead>
                        <tr >
                            <th class="th1">  item Name   </th>
                            <th class="th1">   price </th>
                            <th class="th1">  quantity</th>
                            <th class="th1"> total price </th>
                            <th class="th1">   Action  </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sql1="SELECT *FROM cart ";
                        $result=mysqli_query($conn,$sql1); 
                        session_start();
                        $st=0;
                        // $row=mysqli_fetch_array($result,MYSQLI_ASSOC); 
                        if ( $result) { ?>
                            <?php while($data=mysqli_fetch_assoc( $result)) { ?>
                                <tr > 
                                    <td class="td1"><?php  echo $data['iname'];?></td>
                                    <td class="td1"><?php  echo $data['price'];?></td>
                                    <td class="td1"><?php  echo $data['quality'];?></td>
                                    <td class="td1"><?php echo  $tprice=$data['price']*$data['quality'];$st=$st+$tprice; ?></td>
                    
                                    <input type="hidden" name="id" value="<?=$data["serid"]?>">
                                    <td class="td1"><a href="cartview.php?rn=<?= $data["serid"];?>" class="block">Delete</a>
                                    <a href="customerview.php" class="block">Add More</a></td>
                                </tr>
                             <?php } ?>
                        <?php } ?>
                    </tbody>
                </table>
                <div class="tb3">
                <table class="tabl2">
                    <tbody class="tabl2">
                        <tr >
                            <td class="td1 tabl2"> Sub Total  </td>
                            <td class="td1"><?php  echo $st;?></td>
                        </tr>
                        <tr>
                            <td class="td1">  Delivery Charge </td>
                            <td class="td1"> 30 </td>
                        </tr>
                        <tr>
                            <td class="td1">  total</td>
                            <td class="td1"><?php  echo $st+30;?></td>
                        </tr>
                        <tr>
                            <td class="td1"><a href="order.php"><h3> confirm order</h3></a></td>
                        </tr>
                    </tbody>
                </table></div>
           </div>
           


           <?php
                $plid=$_GET['rn'];
                $query="DELETE FROM cart where serid='$plid'";
                $data=mysqli_query($conn,$query);
            ?>
           


        
    </body>
</html>


