<?php 
$conn=mysqli_connect("localhost","root","","app_user");
$sql="SELECT plantname,plantdescribtion,price,plantcatagory, status, plantid,image FROM plantsdata";
$result=mysqli_query($conn,$sql);
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
  </head>
  <body>
  <ul>
         <li style="float:left"><h3 id="i1">nursery store</h3></li>
         <li><a href="index.php">About Us</a></li>
         <li><a href="index.php">Contact Us</a></li>
         <li><a href="signup.html"  >Registration</a></li> 
         <li><a href="log.html" >Log In</a></li>
         <li><a href="cartview.php" >Back</a></li></ul>
    <?php 
      if ($result) {
        $i=0; 
        while($data=mysqli_fetch_array($result)) { 
          $arr[$i]=$data['plantname'];
          $arr1[$i]=$data['price'];
          $arr2[$i]=$data['image'];
          $i++;
                     
        } 
       }
    ?>

    <div class="container ">
      <h1 style="text-align:center">Shop  PLANTS</h1>
      <?php for ($a=0;$a<$i;$a++){?>
        <div class="row">
          <div class="col-sm-4 "> 
            <div> <form method="post" action="cartview.php?id=<?php //echo $data["plantid"];?>"> 
            <img src="<?=$arr2[$a];?>" width="300"height="250">        
            <div > <?= $arr[$a];?></div>
            <div >$<?=number_format($arr1[$a],2);?></div>
            <input type="number" name="quantity" value="1">
            <input type="hidden" name="hiddename" value="<?=$arr[$a]?>">
            <input type="hidden" name="hiddenprice" value="<?=$arr1[$a]?>">
            <div class="dn">
              <input type="submit" name="add" class="cart" value="Add to Cart"></a>
            </div>
            <?php $a++;?>
            </form></div>        
          </div>
          <?php if($a!=$i){?>
            <div class="col-sm-4">     
              <div> <form method="post" action="cartview.php?id=<?php //echo $data["plantid"];?>"> 
              <img src="<?=$arr2[$a];?>" width="300"height="250">
              <div> <?= $arr[$a];?></div>
              <div>$<?=number_format($arr1[$a],2);?></div>
              <input type="number" name="quantity" value="1">
              <input type="hidden" name="hiddename" value="<?=$arr[$a]?>">
              <input type="hidden" name="hiddenprice" value="<?=$arr1[$a]?>">
              <div class="dn">
                <input type="submit" name="add" class="cart" value="Add to Cart"></a>
              </div>
              <?php $a++;?>
              </form></div>
            </div>
          <?php }?>
          <?php  if($a!=$i){?>
            <div class="col-sm-4">             
              <div> <form method="post" action="cartview.php?id=<?php //echo $data["plantid"];?>"> 
              <img src="<?=$arr2[$a];?>" width="300"height="250">
              <div> <?= $arr[$a];?></div>
              <div>$<?=number_format($arr1[$a],2);?></div>
              <input type="number" name="quantity" value="1">
              <input type="hidden" name="hiddename" value="<?=$arr[$a]?>">
              <input type="hidden" name="hiddenprice" value="<?=$arr1[$a]?>">
              <div class="dn">
                <input type="submit" name="add" class="cart" value="Add to Cart"></a>
              </div>
              </form></div>
            </div>
          <?php }?>
        </div> 
        
      <?php }?>   
        
    </div>









     <!--<h1> Plant Cart</h1>
        <?php 
         //if ($result) { 
            // while($data=mysqli_fetch_array($result)) { ?>
               <div> <form method="post" action="cartview.php?id=<?php //echo $data["plantid"];?>">
               <br>
               <img src="<?//=$data['image'];?>" width="100"height="70">
               <div> <?//= $data['plantname'];?></div>
               <div>$<?//=number_format($data['price'],2);?></div>
               <input type="number" name="quantity" value="1">
                <br><br>
                <input type="hidden" name="hiddename" value="<?//=$data["plantname"]?>">
                <input type="hidden" name="hiddenprice" value="<?//=$data["price"]?>">
               <input type="submit" name="add" value="Add to Cart">
               
            </form>
             </div>
            <?php //}
            //}?>
            <a href="signout.php">sign out</a>-->
</body>
</html>