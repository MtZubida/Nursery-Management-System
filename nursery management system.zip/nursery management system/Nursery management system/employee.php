<?php 
$conn=mysqli_connect("localhost","root","","app_user");
$sql="SELECT eid,ename,eage,emailid,ephn,status  FROM edata";
$result=mysqli_query($conn,$sql);


?>
<!DOCTYPE html>
<html lang="en">
<head>
   
</head>
<body>
    <a href='eadd.php'><h3> Add Employee</h3></a>
    <h1>Manage Employees</h1>
<table >
    <thead>
        <tr>
        <th>email id  &nbsp;&nbsp;&nbsp </th>
        <th>  employee Name  &nbsp;&nbsp;&nbsp </th>
        <th>  employee age  &nbsp;&nbsp;&nbsp</th>
        <th>  emailid &nbsp;&nbsp;&nbsp</th>
        <th> phn number  &nbsp;&nbsp;&nbsp</th>
        <th>Status&nbsp;&nbsp;&nbsp</th>
        <th>   Action  &nbsp;&nbsp;&nbsp </th>
</tr>
    </thead>
    <tbody>
        <?php 
         if ($result) { ?>
            <?php while($data=mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php  echo $data['eid']; ?>&nbsp;&nbsp;&nbsp;&nbsp</td>
                    <td><?php  echo $data['ename'];?>&nbsp;&nbsp;&nbsp;&nbsp</td>
                    <td><?php  echo $data['eage'];?>&nbsp;&nbsp;&nbsp</td>
                    <td><?php  echo $data['emailid'];?>&nbsp;&nbsp;&nbsp</td>
                    <td><?php  echo $data['ephn'];?>&nbsp;&nbsp;&nbsp</td>
                    <td><?php echo $data['status']; ?>&nbsp;&nbsp;&nbsp;&nbsp</td>
                   <td><a href="eupdate.php ?rn=<?php echo $data["eid"]; ?>">Update</a></td>
                   <td><a href="edelete.php ?rn=<?php echo $data["eid"]; ?>">Delete</a></td>
                </tr>
            <?php } ?>
        <?php } ?>
    </tbody>
</table>
<a href="plantdetail.php"><h3> Home</h3></a>
<a href="index.php"><h3> sign out</h3></a>
</body>
</html>

