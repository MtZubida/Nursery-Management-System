<!DOCTYPE html>
<html lang="en">
<head>
   
</head>
    <body>
    <ul>
         <li style="float:left"><h3 id="i1">nursery store</h3></li>
         <li><a href="index.php">About Us</a></li>
         <li><a href="index.php">Contact Us</a></li>
         <li><a href="signup.html"  >Registration</a></li> 
         <li><a href="log.html" >Log In</a></li></ul>
        <h1>My Cart</h1>
        <table >
            <thead>
                <tr>
                    <th>  item Name  &nbsp;&nbsp;&nbsp </th>
                    <th>   price &nbsp;&nbsp;&nbsp</th>
                    <th>  quality&nbsp;&nbsp;&nbsp</th>
                    <th> total price  &nbsp;&nbsp;&nbsp</th>
                    <th>   Action  &nbsp;&nbsp;&nbsp </th>
                </tr>
            </thead>
            <tbody>
                <?php
                   if(isset($_POST["add"])){
    
                    $itemid=$_GET["id"];
                    $iname=$_POST["hiddename"];
                    $iprice=$_POST["hiddenprice"];
                    $quality=$_POST["quantity"];
                    echo $iname;
                ?>
                <tr> 
                   <td><?php  $iname;?>&nbsp;&nbsp;&nbsp;&nbsp</td>
                   <td><?php $iprice;?>&nbsp;&nbsp;&nbsp</td>
                   <td><?php  echo $quality;?>&nbsp;&nbsp;&nbsp</td>
                   <td><?php echo  $tprice=$iprice*$ $quality; ?>&nbsp;&nbsp;&nbsp;&nbsp</td>
                   <input type="hidden" name="id" value="<?=$itemid?>">
                   <td><a href="idelete.php?rn=<?= $data["serid"];?>">Delete</a></td>
                </tr>
                <?php }?>
            </tbody>
        </table>
        <td><a href="customerview.php">Add More</a></td>
        <a href="order.php"><h3> confirm order</h3></a>
    </body>
</html>