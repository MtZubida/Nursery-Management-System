<!DOCTYPE html>
<html lang="en">
    <head>
        
        <link rel="stylesheet" href="payment.css">
        <link rel="stylesheet" href="style.css">
    </head>
        <body>
            <ul>
         <li style="float:left"><h3 id="i1">nursery store</h3></li>
         <li><a href="index.php">About Us</a></li>
         <li><a href="index.php">Contact Us</a></li>
         <li><a href="signup.html"  >Registration</a></li> 
         <li><a href="log.html" >Log In</a></li>
         <li><a href="index.php">Home</a></li>
        </ul>
         
            <header>
                <div class="container">
                    <div class="left">
                        <h3>BILLING ADRESS</H3>
                        <form class="abc">
                        Full name
                        <input type="text" placeholder="Enter Name" >
                        Email
                        <input type="text" placeholder="Enter EMAIL">
                        Address
                        <input type="text" placeholder="Enter  Adress">
                        City
                        <input type="text" placeholder="Enter city">
                        Phone Number
                        <input type="text" placeholder="Enter city">
                         </form>
                    </div>
                    <div class="right">
                        <h3>PAYMENT</h3>
                        <input type="radio">
                          cash on delivery
                          <a href="order.php"><h3> Proceed to checkout</h3></a>
                    </div>
                </div>
            </header>
<?php
echo"order confirm";
?>
        </body>
</html>


<?php
    echo"order confirm";
 if(session_start()){
    echo"order confirm";
 }

   /* session_start();
    $conn=mysqli_connect("localhost","root","","app_user");
    //$id=2;
    //$odate=0;


    $sql2="SELECT MAX(orderid)+1 AS orderid FROM orderecord";
    $result=mysqli_query($conn,$sql2);
    while($data1=mysqli_fetch_assoc( $result))
    {
        $emailid=$_SESSION['emailid'];
        $id=$data1['orderid'];
        //$odate=$data1['odate'];
        $dt = getdate();
        $sql="INSERT INTO orderecord(orderid,emailid) VALUES ('$id','$emailid')";
        $result3=mysqli_query($conn,$sql); 
    } 
    header ("refresh:2; url=cartview.php");

?>*/

