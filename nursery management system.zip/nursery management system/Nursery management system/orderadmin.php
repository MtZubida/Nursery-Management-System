
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<ul>
         <li style="float:left"><h3 id="i1">nursery store</h3></li>
         <li><a href="index.php"> sign out</a></li>
         <li><a href="index.php">About Us</a></li>
         <li><a href="index.php">Contact Us</a></li>
         <li><a href="signup.html"  >Registration</a></li> 
         <li><a href="log.html" >Log In</a></li></ul>
    <h1>order list</h1>
<table class="tabl1">
    <thead>
        <tr>
        <th class="th1">  Order Id   </th>
        <th class="th1">  emailid </th>
        <th class="th1">   Action   </th>
</tr>
    </thead>
    <tbody>
    <?php 
    $conn=mysqli_connect("localhost","root","","app_user");
    $sql1="SELECT *FROM orderecord ";
    $result=mysqli_query($conn,$sql1); 
   // $row=mysqli_fetch_array($result,MYSQLI_ASSOC); 
         if ( $result) { ?>
            <?php while($data=mysqli_fetch_assoc( $result)) { ?>
                <tr> 
                    <td class="td1"><?php  echo $data['orderid'];?></td>
                    <td class="td1"><?php  echo $data['emailid'];?>p</td>
                    <input type="hidden" name="id" value="<?=$data["orderid"]?>">
                   <td class="td1"><a href="odelete.php?rn=<?= $data["orderid"];?>">Delete</a></td>
                </tr>
            <?php } ?>
        <?php } ?>
    </tbody>
</table>
<a href="plantdetail.php"><h3> Back</h3></a>
</body>
</html>
