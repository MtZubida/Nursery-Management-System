<!DOCTYPE html>
<html lang="en">
<head>

</head>
<body>
    <h1>Add Employee</h1>
    <form action="eadd.php" method="post" enctype="multipart/form-data">
        Employeename   <input type="text" name="ename"><br><br>
        Employee age  <input type ="text" name="eage"><br><br>
        Emailid  <input type="text" name="emailid"><br><br>
        phonenumber <input type="number" name="ephn"><br><br>
        status<input type="radio" name="sname" value="Active">
        Active
        <input type="radio" name="sname" value="inactive">
        Inactive
        <br><br>
        <input type ="submit" name="submit">
        <a href="employee.php"><h2> back</h2></a> 

</form>
</body>
</html>

<?php

if(isset($_POST["submit"])){

      
         $pname = $_POST["ename"];
         $pdis=$_POST["eage"];
         $pr=$_POST["emailid"];
        $pcat=$_POST["ephn"];
        $satus=$_POST["sname"];
    $conn=mysqli_connect("localhost","root","","app_user");
    $sql="SELECT  *FROM edata WHERE ename = '$pname'  ";
              $result=mysqli_query($conn,$sql);
              $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
              $count=mysqli_num_rows($result);
              //echo $count;
           if($count==0){
                    $sql="INSERT INTO edata(ename,eage,emailid,ephn,status)
                    VALUES ('$pname',' $pdis','$pr' ,'$pcat','$satus')";

              if(mysqli_query($conn,$sql)){

                  session_start();

                  $_SESSION["ename"]=$_POST["ename"];

                  echo"Registration Accepted<br>";

                  header ("refresh:2; url=employee.php");
              }
                 }
            else{
                echo "multiple plant present";
                header("refresh:2; url=eadd.php");
            }
            
     
            
        
}

?>