<?php
$conn=mysqli_connect("localhost","root","","app_user");
$plid=$_GET['rn'];


$query="DELETE FROM orderecord  where orderid='$plid'";
$data=mysqli_query($conn,$query);
if($data){
    echo "delete item";
    header ("refresh:3; url=orderadmin.php");
}else{
    echo"item not delete ";
    header ("refresh:2; url=orderadmin.php");
}
?>