<?php 
    $conn=mysqli_connect("localhost","root","","app_user");
    $sql="SELECT plantname,plantdescribtion,price,plantcatagory, status, plantid FROM plantsdata";
     $result=mysqli_query($conn,$sql);


?>
<!DOCTYPE html>
    <html lang="en">
        <head>
        <link rel="stylesheet" href="style.css">
        </head>
            <body>
            <ul>
         <li style="float:left"><h3 id="i1">nursery store</h3></li>
         <li><a href="index.php"> sign out</a></li>
         <li><a href="index.php">About Us</a></li>
         <li><a href="index.php">Contact Us</a></li>
         <li><a href="signup.html"  >Registration</a></li> 
         <li><a href="log.html" >Log In</a></li></ul>


                <h1 style="text-align=center">Manage Plant Details</h1>
                <table  class="tabl1">
                    <thead>
                        <tr>
                            <th class="th1">Serial No  </th>
                            <th class="th1">  plant Name  </th>
                            <th class="th1">  plant describtion  </th>
                            <th class="th1">  price  </th>
                            <th class="th1">  plant catagory  </th>
                            <th class="th1">Status</th>
                            <th class="th1">   Action   </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            if ($result) { ?>
                                <?php while($data=mysqli_fetch_assoc($result)) { ?>
                                    <tr>
                                        <td class="td1"><?php  echo $data['plantid']; ?></td>
                                        <td class="td1"><?php  echo $data['plantname'];?></td>
                                        <td class="td1"><?php  echo $data['plantdescribtion'];?></td>
                                        <td class="td1"><?php  echo $data['price'];?></td>
                                        <td class="td1"><?php  echo $data['plantcatagory'];?></td>
                                        <td class="td1"><?php echo $data['status']; ?></td>
                                        <td class="td1"><a href="update.php ?rn=<?php echo $data["plantid"];?> &pn=<?php echo $data["plantname"];?>
                                        &pd=<?php echo $data["plantdescribtion"];?> &pr=<?php echo $data["price"];?>
                                        &pc=<?php echo $data["plantcatagory"];?> &st=<?php echo $data["status"];?>" class="block">Update</a></td>
                                        <td class="td1"><a href="delete.php ?rn=<?php echo $data["plantid"]; ?>" class="block">Delete</a></td>
                                        <td class="td1"><a href='plantsentre.php' class="block">Add Plant</a></td>
                                        <td class="td1"><a href='plantdetail.php' class="block">back</a></td>
                                    
                                    </tr> 
                                <?php } ?>
                            <?php } ?>
                    </tbody>
                </table>

            </body>
    </html>

