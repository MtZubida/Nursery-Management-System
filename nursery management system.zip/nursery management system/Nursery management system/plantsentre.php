<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="log.css">
</head>
<body class="bd1">
    
    <form action="plantsentre.php" method="post" enctype="multipart/form-data" class="box">
    <h1>Add Plant</h1>
        plantname   <input type="text" name="pname"><br><br>
        plantdescription  <input type ="text" name="dname"><br><br>
        price   <input type="number" name="price"><br><br>
        product catagory <input type="text" name="pca"><br><br>
        Image  <input type="file" name="image"><br><br>
        status<input type="radio" name="sname" value="Available">
        Available
        <input type ="radio" name="sname" value="not available">
        Not Available
        <br><br>
        <input type ="submit" name="submit">
        <a href="plantinsert.php" class="bv1"><h2> cancell</h2></a> 

</form>
</body>
</html>

<?php

if(isset($_POST["submit"])){

      
         $pname = $_POST["pname"];
         $pdis=$_POST["dname"];
         $price=$_POST["price"];
        $pcat=$_POST["pca"];
        $satus=$_POST["sname"];
        $img=$_FILES["image"]["name"];
    $conn=mysqli_connect("localhost","root","","app_user");
    $sql="SELECT  *FROM plantsdata WHERE plantname = '$pname'  ";
              $result=mysqli_query($conn,$sql);
              $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
              $count=mysqli_num_rows($result);
              //echo $count;
           if($count==0){
                    $sql="INSERT INTO plantsdata(plantname,plantdescribtion,price,plantcatagory,status,image)
                    VALUES ('$pname',' $pdis','$price' ,'$pcat','$satus','$img')";

              if(mysqli_query($conn,$sql)){

                  session_start();

                  $_SESSION["plantname"]=$_POST["pname"];

                  echo"Registration Accepted<br>";

                  header ("refresh:2; url=plantinsert.php");
              }
                 }
            else{
                echo "multiple plant present";
                header("refresh:2; url=plantsentre.php");
            }
            
     
            
        
}

?>