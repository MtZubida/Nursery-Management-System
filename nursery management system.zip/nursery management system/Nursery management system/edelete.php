<?php
$conn=mysqli_connect("localhost","root","","app_user");

$plid=$_GET['rn'];

$query="DELETE FROM edata where eid='$plid'";
$data=mysqli_query($conn,$query);
if($data){
    echo "REcord deleted from database";
    header ("refresh:3; url=employee.php");
}else{
    echo"record not delete from database";
    header ("refresh:2; url=employee.php");
}






?>